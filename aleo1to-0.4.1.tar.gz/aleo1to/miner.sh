#!/usr/bin/env bash
trap 'while killall 1to-miner > /dev/null 2>&1;do sleep 1;done;exit 0' SIGTERM
unset CUDA_VISIBLE_DEVICES
declare -a params=("$@")

if [[ "${params[@]}" =~ "devices" ]]; then
    devs=$(echo ${params[@]} |grep -E "devices" |cut -d '=' -f2 |cut -d '-' -f1)
    export CUDA_VISIBLE_DEVICES=${devs}
    cmd_line=$(echo ${params[@]} |sed -e "s/--devices=${devs}//g")
    ./1to-miner ${cmd_line}
else
    ./1to-miner ${params[@]}
fi
