####################################################################################
###
### aleo1tominer
###
####################################################################################

#!/usr/bin/env bash
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/aleo1tominer/h-manifest.conf

conf="--address ${CUSTOM_TEMPLATE} --ws ${CUSTOM_URL}"


[[ ! -z $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

echo "$conf"
echo "$conf" > $CUSTOM_CONFIG_FILENAME

