#!/usr/bin/env bash








echo -e " --enable_telemetry_api --url=$CUSTOM_URL --template=$CUSTOM_TEMPLATE --pass=$CUSTOM_PASS " > $CUSTOM_CONFIG_FILENAME