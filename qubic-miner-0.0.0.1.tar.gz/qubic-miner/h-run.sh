#!/usr/bin/env bash

. h-manifest.conf


echo $CUSTOM_NAME
echo $CUSTOM_LOG_BASENAME
echo $CUSTOM_CONFIG_FILENAME


CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

rm -rf "$CUSTOM_LOG_BASENAME.log"

qubic-miner | tee --append "$CUSTOM_LOG_BASENAME.log"




