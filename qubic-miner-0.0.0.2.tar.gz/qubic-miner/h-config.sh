#!/usr/bin/env bash

#rm -rf /qub-hive
#mkdir /qub-hive

echo -e "{\n  \"Settings\":\n  {\n    \"baseUrl\": \"$CUSTOM_URL\",\n    $CUSTOM_PASS,\n    \"payoutId\": null,\n    \"accessToken\": \"$CUSTOM_TEMPLATE\",\n    \"autoupdateEnabled\":true,\n    $CUSTOM_USER_CONFIG\n  }\n}" > $CUSTOM_CONFIG_FILENAME

