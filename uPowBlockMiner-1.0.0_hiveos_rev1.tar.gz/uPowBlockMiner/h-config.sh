####################################################################################
###
### uPowBlockMiner
###
####################################################################################

#!/usr/bin/env bash
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/uPowBlockMiner/h-manifest.conf

conf=""
conf+=" -node $CUSTOM_URL -address $CUSTOM_TEMPLATE


[[ ! -z $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

echo "$conf"
echo "$conf" > $CUSTOM_CONFIG_FILENAME

