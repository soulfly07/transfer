#!/usr/bin/env bash


echo -e "--rpc=$CUSTOM_PASS" > $CUSTOM_CONFIG_FILENAME

