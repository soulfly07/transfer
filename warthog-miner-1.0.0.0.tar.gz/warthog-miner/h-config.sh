#!/usr/bin/env bash


echo -e " --address=$CUSTOM_TEMPLATE --host=$CUSTOM_URL --port=$CUSTOM_PASS" > $CUSTOM_CONFIG_FILENAME

