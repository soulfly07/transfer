####################################################################################
###
### xelis-taxminer-old
###
####################################################################################

#!/usr/bin/env bash
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/xelis-taxminer-old/h-manifest.conf

conf=""
conf+=" --host $CUSTOM_URL --wallet $CUSTOM_TEMPLATE"


[[ ! -z $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

echo "$conf"
echo "$conf" > $CUSTOM_CONFIG_FILENAME

