####################################################################################
###
### xelis_miner
###
####################################################################################

#!/usr/bin/env bash
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/sedra-miner/h-manifest.conf
#[[ -e /hive/miners/custom ]] && . /hive/miners/custom/sedra-miner/h-manifest.conf
conf=""
conf+=" --daemon-address $CUSTOM_URL --miner-address $CUSTOM_TEMPLATE" --worker $CUSTOM_WORKER_NAME


[[ ! -z $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

echo "$conf"
echo "$conf" > $CUSTOM_CONFIG_FILENAME

