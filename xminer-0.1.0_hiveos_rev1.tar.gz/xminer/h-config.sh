####################################################################################
###
### xminer
###
####################################################################################

#!/usr/bin/env bash
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/xminer/h-manifest.conf

conf=""
conf+=" --daemon-address $CUSTOM_URL -m $CUSTOM_TEMPLATE


[[ ! -z $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

echo "$conf"
echo "$conf" > $CUSTOM_CONFIG_FILENAME

